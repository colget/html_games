package com.example.blackjackshoe;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(android.graphics.Color.rgb(15, 73, 55));
    getWindow().setNavigationBarColor(android.graphics.Color.rgb(15, 73, 55));
    WebView web = new WebView(this);
    web.setBackgroundColor(android.graphics.Color.rgb(17, 84, 62));
    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(false);
    settings.setAllowFileAccess(true);
    settings.setAllowContentAccess(false);
    web.setVerticalScrollBarEnabled(false);
    web.setHorizontalScrollBarEnabled(false);
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
}
