# Blackjack Shoe (Android project source)

An offline Android WebView app for blackjack practice. Features include:
- Finite shuffled shoe (1, 2, 6, or 8 decks), cards removed when dealt
- Hi-Lo running count and true count, based on exposed cards and remaining shoe size
- Manual shuffle and automatic shuffle at configurable shoe penetration
- Virtual bank and independent reset-bank control
- Large touch-friendly Hit / Stand / Double / Split buttons
- Basic strategy guidance panel
- Configurable starting bank and dealer soft-17 rule

## Build an APK

This source project requires Android Studio or a machine with JDK 17+, Android SDK platform 35, and Gradle 8.9+.

1. Open this folder in Android Studio.
2. Let Gradle sync and install any requested Android SDK components.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will place the debug APK under `app/build/outputs/apk/debug/`.

This environment did not have the Android SDK or Gradle installed, so an APK was not compiled here. The project source is provided for building in Android Studio.

## Notes

- No network permissions or real-money functions are included.
- This is a practice simulator, not a casino-certified blackjack engine. The basic-strategy adviser covers common decisions and is an approximation; strategy varies by table rules. The shoe and Hi-Lo counters are implemented locally.
- Virtual bank and game state are reset when the app process restarts; persistent save support is not currently implemented.
